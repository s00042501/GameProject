package com.example.gameproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlinx.android.synthetic.main.activity_game.*
import com.example.gameproject.R.drawable.*

class GameActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game) }

    //show a timer on the top of the screen
// after the player finish the game, it will show a toast message "congratulation"
//  Then the user click on Close the Game button and it will move to the feedback activity
    fun callFeedbackActivity(view: View?){
        val moveToLast = Intent(this, FeedbackActivity::class.java)
        startActivity(moveToLast)
    }

        //using an array to store image cards
        //shuffle images to the different columns during each play time
      /*  val images:MutableList<Int> =
            mutableListOf(R.drawable.frozen_anna,R.drawable.frozen_elsa, R.drawable.frozen_olaf,R.drawable.frozen_anna,R.drawable.frozen_elsa, R.drawable.frozen_olaf)

        //creating an array of buttons card
        val buttons = arrayOf(button1, button2, button3, button4, button5, button6)

        val cardBack = questionmark  (check this image not int variable)
        // to prevent the player from looking to all cards at once, we have to create some variable below
        var clicked = 0      //track how many cards are clicked
        var turnOver = false   //check if two cards are turned over
        var lastClicked = -1   // what is the last cards for matching

        //  randomizing images for each play time
        images.shuffle()

        //using for loop to push images into buttons

        for (i:Int in 0..5){
            buttons[i].setBackgroundResource(R.drawable.frozen_anna)
            buttons[i].text= "cardBack"
            buttons[i].textSize =0.0F
            buttons[i].setOnClickListener {
                //check if buttons text equal to cardBack then turn over
                if (buttons[i].text == "cardBack" && !turnOver) {
                    buttons[i].setBackgroundResource(images[i])
                    buttons[i].setText(images[i])
                    if (clicked == 0) {
                        lastClicked = 1
                    }
                    clicked++
                }
                //return images to questionmark image
                else if (buttons[i].text !in "cardBack") {
                    buttons[i].setBackgroundResource(cardBack)
                    buttons[i].text = "cardBack"
                    clicked--  // how many cards face up
                }
                if(clicked == 2) {
                    turnOver = true
                    if (buttons[i].text == buttons[lastClicked]) {
                        buttons[i].isClickable = false
                        buttons[lastClicked].isClickable = false
                        turnOver = false
                        clicked = 0
                    }
                } else if (clicked == 0) {
                    turnOver = false
                }


            }

            }
        }
*/

}
